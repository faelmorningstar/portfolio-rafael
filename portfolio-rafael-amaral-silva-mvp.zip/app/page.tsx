"use client";

import { useEffect, useMemo, useRef, useState } from "react";

const DRAGON = [
  "             /\\                 /\\",
  "        ____/  \\____       ____/  \\____",
  "      /-.       .-\\     /-.       .-\\",
  "     /    \\  /\\  /    \\_/    \\  /\\  /    \\",
  "    /      \\/  \\/      /      \\/  \\/      \\",
  "   <       /\\  /\\     <  RA   /\\  /\\       >",
  "    \\     /  \\/  \\     \\     /  \\/  \\     /",
  "     \\___/   /\\   \\_____\\___/   /\\   \\___/",
  "         \\__/  \\__/         \\__/  \\__/",
  "            \\    /\\   /\\   /    /",
  "             \\__/  \\_/  \\__/",
  "                 \\  |  /",
  "                  \\_|_/",
  "                   /_\\",
].join("\n");

const PROJECTS = [
  { name: "OulDesign", skill: "FRONT-END", tech: "HTML · CSS · JavaScript · Three.js" },
  { name: "Quick Filler", skill: "PYTHON / APIs", tech: "Python · FastAPI · OCR · Docker" },
  { name: "Project Pixel", skill: "NEXT.JS / TYPESCRIPT", tech: "Next.js · TypeScript · Tailwind CSS" },
];

function AnimatedEyeCursor() {
  const [visible, setVisible] = useState(false);
  const [frame, setFrame] = useState(0);
  const position = useRef({ x: 0, y: 0 });
  const cursorRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const move = (event: PointerEvent) => {
      position.current = { x: event.clientX, y: event.clientY };
      if (cursorRef.current) cursorRef.current.style.transform = `translate3d(${event.clientX + 8}px,${event.clientY + 8}px,0)`;
      const element = event.target instanceof Element ? event.target : null;
      setVisible(Boolean(element?.closest("p,h1,h2,h3,.selectable-text")) && !Boolean(element?.closest("a,button,[tabindex]")));
    };
    const timer = window.setInterval(() => setFrame((value) => (value + 1) % 3), 130);
    window.addEventListener("pointermove", move);
    return () => { window.clearInterval(timer); window.removeEventListener("pointermove", move); };
  }, []);
  return <div ref={cursorRef} className={`eye-cursor ${visible ? "is-visible" : ""}`} aria-hidden="true"><img src={`/cursors/eye-${frame}.png`} alt="" /></div>;
}

function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(query.matches);
    update(); query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  return reduced;
}

function CodeRain({ active }: { active: boolean }) {
  const streams = useMemo(() => Array.from({ length: 26 }, (_, i) => ({
    id: i, left: `${(i * 37) % 101}%`, delay: `${-((i * 0.19) % 1.8)}s`,
    duration: `${1.25 + ((i * 13) % 9) / 10}s`,
    text: Array.from({ length: 10 }, (__, j) => ((i + j * 3) % 4 ? "0" : "1")).join("\n"),
  })), []);
  return <div className={`code-rain ${active ? "is-active" : ""}`} aria-hidden="true">
    {streams.map((s) => <span key={s.id} style={{ left:s.left, animationDelay:s.delay, animationDuration:s.duration }}>{s.text}</span>)}
  </div>;
}

function Hero() {
  const reduced = useReducedMotion();
  const [phase, setPhase] = useState(reduced ? 3 : 0);
  useEffect(() => {
    if (reduced) { setPhase(3); return; }
    const timers = [window.setTimeout(() => setPhase(1), 900), window.setTimeout(() => setPhase(2), 1750), window.setTimeout(() => setPhase(3), 2850)];
    return () => timers.forEach(window.clearTimeout);
  }, [reduced]);
  return <section className={`hero phase-${phase}`} id="inicio" aria-labelledby="hero-title">
    <CodeRain active={phase === 1 || phase === 2} />
    <div className="orbit-shell" aria-hidden="true">
      <span className="orbit-copy orbit-copy-top">SOLVE ET COAGULA</span>
      <span className="orbit-copy orbit-copy-bottom">EXPERIÊNCIA · CÓDIGO · TRANSFORMAÇÃO</span>
    </div>
    <div className="identity-circle">
      <pre className="dragon-ascii" aria-hidden="true">{DRAGON}</pre>
      <img className="portrait" src="/rafael.png" alt="Retrato de Rafael Amaral Silva" />
    </div>
    <div className="hero-copy">
      <p className="eyebrow">PORTFÓLIO · 2026</p>
      <h1 id="hero-title">Rafael Amaral Silva</h1>
      <p>Desenvolvedor de Software Júnior</p>
      <nav className="hero-actions" aria-label="Acessos principais">
        <a className="scroll-button" href="#projetos">Projetos</a><a className="scroll-button" href="#contato">Contato</a>
      </nav>
    </div>
    <a className="scroll-cue" href="#trajetoria" aria-label="Ir para trajetória">↓</a>
  </section>;
}

function MagicRings() {
  const canvasRef = useRef<HTMLCanvasElement>(null); const frameRef = useRef(0);
  const pointer = useRef({ x:0, y:0, tx:0, ty:0, inside:false }); const reduced = useReducedMotion();
  useEffect(() => {
    const canvas=canvasRef.current, ctx=canvas?.getContext("2d"); if(!canvas||!ctx)return;
    const resize=()=>{const r=canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio,2);canvas.width=r.width*d;canvas.height=r.height*d;ctx.setTransform(d,0,0,d,0,0)};
    const move=(e:PointerEvent)=>{const r=canvas.getBoundingClientRect();pointer.current.tx=e.clientX-r.left-r.width/2;pointer.current.ty=e.clientY-r.top-r.height/2;pointer.current.inside=true};
    const leave=()=>{pointer.current.tx=0;pointer.current.ty=0;pointer.current.inside=false};
    const draw=(time=0)=>{const w=canvas.clientWidth,h=canvas.clientHeight;ctx.clearRect(0,0,w,h);pointer.current.x+=(pointer.current.tx-pointer.current.x)*.06;pointer.current.y+=(pointer.current.ty-pointer.current.y)*.06;const base=Math.min(w,h)*.17;
      for(let ring=0;ring<7;ring++){const radius=base+ring*Math.min(w,h)*.047;ctx.beginPath();for(let i=0;i<=180;i++){const a=i/180*Math.PI*2,prox=pointer.current.inside?Math.max(0,1-Math.hypot(Math.cos(a)*radius-pointer.current.x,Math.sin(a)*radius-pointer.current.y)/190):0,wave=reduced?0:Math.sin(a*4+time*.0015+ring)*(2+prox*13),x=w/2+Math.cos(a)*(radius+wave)+pointer.current.x*prox*.04,y=h/2+Math.sin(a)*(radius+wave)+pointer.current.y*prox*.04;i?ctx.lineTo(x,y):ctx.moveTo(x,y)}ctx.strokeStyle=ring%2?"rgba(245,247,250,.34)":"rgba(255,255,255,.74)";ctx.lineWidth=ring%3===0?1.25:.7;ctx.stroke()}
      if(!reduced)frameRef.current=requestAnimationFrame(draw)};
    resize();draw();window.addEventListener("resize",resize);canvas.addEventListener("pointermove",move);canvas.addEventListener("pointerleave",leave);
    return()=>{cancelAnimationFrame(frameRef.current);window.removeEventListener("resize",resize);canvas.removeEventListener("pointermove",move);canvas.removeEventListener("pointerleave",leave)};
  },[reduced]);
  return <canvas ref={canvasRef} className="magic-rings" aria-label="Anéis digitais que reagem ao cursor"/>;
}

function Trajectory(){return <section className="trajectory section-pad" id="trajetoria" aria-labelledby="trajectory-title">
  <p className="section-index">01 · TRAJETÓRIA</p><h2 id="trajectory-title" className="sr-only">Trajetória</h2>
  <div className="trajectory-grid">
    <article className="trajectory-copy trajectory-solve"><h3 className="chrome-title">Solve</h3><p>O Serviço Social me ensinou a compreender pessoas, contextos e problemas reais. Questionar estruturas e reorganizar caminhos faz parte da minha forma de trabalhar.</p></article>
    <div className="rings-stage"><MagicRings/><p>Experiência humana + conhecimento + tecnologia</p></div>
    <article className="trajectory-copy trajectory-coagula"><h3 className="chrome-title">Coagula</h3><p>Na tecnologia, integro essa experiência ao desenvolvimento de interfaces, Python, APIs e automações com IA. Hoje estudo Análise e Desenvolvimento de Sistemas e construo projetos para atuar como Desenvolvedor de Software Júnior.</p></article>
  </div>
</section>}

function Projects(){const[active,setActive]=useState(1);return <section className="projects section-pad" id="projetos" aria-labelledby="projects-title">
  <div className="section-heading"><p className="section-index">02 · PROJETOS</p><h2 id="projects-title">Competências demonstradas em projetos reais</h2></div>
  <div className="skill-stage" aria-live="polite"><p className="skill-word" key={PROJECTS[active].skill} aria-hidden="true">{PROJECTS[active].skill.split("").map((c,i)=><span key={`${c}-${i}`} style={{animationDelay:`${i*18}ms`}}>{c===" "?"\u00a0":c}</span>)}</p><span className="sr-only">Competência em foco: {PROJECTS[active].skill}</span></div>
  <div className="project-grid">{PROJECTS.map((p,i)=><article className={`project-tile ${active===i?"is-active":""}`} key={p.name} tabIndex={0} onPointerEnter={()=>setActive(i)} onFocus={()=>setActive(i)} onClick={()=>setActive(i)}>
    <div className="video-placeholder" aria-label={`Vídeo de ${p.name} será inserido posteriormente`}><span>VÍDEO A INSERIR</span></div><h3>{p.name}</h3><p>{p.tech}</p>
  </article>)}</div>
</section>}

function HybridPortrait(){const canvasRef=useRef<HTMLCanvasElement>(null),pointer=useRef({x:-999,y:-999});const reduced=useReducedMotion();useEffect(()=>{const canvas=canvasRef.current,ctx=canvas?.getContext("2d");if(!canvas||!ctx)return;const image=new Image();image.src="/hybrid-portrait.png";let raf=0,loaded=false;const chars="01<>/\\{}[];:·",off=document.createElement("canvas"),offCtx=off.getContext("2d",{willReadFrequently:true});
  const draw=(time=0)=>{const size=canvas.clientWidth,d=Math.min(devicePixelRatio,2);if(canvas.width!==Math.floor(size*d)){canvas.width=size*d;canvas.height=size*d;ctx.setTransform(d,0,0,d,0,0);off.width=120;off.height=120}ctx.clearRect(0,0,size,size);if(loaded&&offCtx){offCtx.clearRect(0,0,120,120);offCtx.drawImage(image,0,0,120,120);const pixels=offCtx.getImageData(0,0,120,120).data,step=3,scale=size/120;ctx.font=`${Math.max(8,scale*3.1)}px ui-monospace,monospace`;ctx.textAlign="center";for(let y=0;y<120;y+=step)for(let x=0;x<120;x+=step){const p=(y*120+x)*4,light=(pixels[p]+pixels[p+1]+pixels[p+2])/765;if(light<.09)continue;let px=x*scale,py=y*scale,dx=px-pointer.current.x,dy=py-pointer.current.y,dist=Math.hypot(dx,dy);if(!reduced&&dist<100&&dist>0){const force=(1-dist/100)*Math.sin(dist*.13-time*.006)*13;px+=dx/dist*force;py+=dy/dist*force}ctx.fillStyle=`rgba(245,247,250,${Math.min(1,light*1.55)})`;ctx.fillText(chars[(x+y)%chars.length],px,py)}}raf=requestAnimationFrame(draw)};
  image.onload=()=>{loaded=true};const move=(e:PointerEvent)=>{const r=canvas.getBoundingClientRect();pointer.current={x:e.clientX-r.left,y:e.clientY-r.top}},leave=()=>{pointer.current={x:-999,y:-999}};canvas.addEventListener("pointermove",move);canvas.addEventListener("pointerleave",leave);raf=requestAnimationFrame(draw);return()=>{cancelAnimationFrame(raf);canvas.removeEventListener("pointermove",move);canvas.removeEventListener("pointerleave",leave)}},[reduced]);return <canvas className="hybrid-canvas" ref={canvasRef} aria-label="Retrato em caracteres: metade Rafael e metade dragão"/>}

function Contact(){return <section className="contact section-pad" id="contato" aria-labelledby="contact-title"><p className="section-index">03 · CONTATO</p><div className="contact-grid"><div className="contact-copy"><h2 id="contact-title" className="chrome-title">Contato</h2><p>Conheça meus projetos e acompanhe minha trajetória profissional.</p><div className="contact-actions"><a className="scroll-button" href="https://www.linkedin.com/in/rafael-amaral-silva-dev/" target="_blank" rel="noreferrer">LinkedIn</a><a className="scroll-button" href="https://github.com/faelmorningstar" target="_blank" rel="noreferrer">GitHub</a></div></div><HybridPortrait/></div><footer><span>Rafael Amaral Silva</span><span>Desenvolvedor de Software Júnior</span></footer></section>}

export default function Home(){return <main><AnimatedEyeCursor/><Hero/><Trajectory/><Projects/><Contact/></main>}
